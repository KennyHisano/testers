//
//  Rolodex.h
//  relodex
//
//  Created by NandN on 2017/11/05.
//  Copyright © 2017 NandN. All rights reserved.
//

#ifndef Rolodex_h
#define Rolodex_h

#include <vector>
#include <iterator>

#include "Card.h"
class Rolodex{
    
private:
    vector<Card> CardVec;
    
public:
    void add(Card& card);
    Card remove();
    Card getCurrentCard();
    Card flip();
    bool search(const std::string& lastname, const std::string& firstname);
    void show(ostream& os);
};

#endif /* Rolodex_h */
