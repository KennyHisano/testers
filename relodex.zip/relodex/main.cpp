//
//  main.cpp
//  relodex
//
//  Created by NandN on 2017/11/04.
//  Copyright © 2017 NandN. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
